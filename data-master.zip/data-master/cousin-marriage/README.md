### Cousin Marriage Data

The raw data behind the story [Dear Mona: How Many Americans Are Married To Their Cousins?]

Header | Definition
---|---------
`percent` | Percent of marriages that are consanguineous

Source: [cosang.net](http://www.consang.net/index.php/Main_Page)