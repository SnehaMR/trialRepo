### Male flight attendants

This repo contains the data from the article on the gender divide in various U.S. occupations

[Dear Mona, How Many Flight Attendants Are Men?](http://fivethirtyeight.com/datalab/dear-mona-how-many-flight-attendants-are-men/)

`male-flight-attendants.tsv`:

The tab-separated text file contains the percentage of U.S. employees that are male in 320 different job categories.

Source: [IPUMS](https://usa.ipums.org/usa/), 2012

