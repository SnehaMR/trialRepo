---
files:
  - https://projects.fivethirtyeight.com/trump-approval-data/approval_polllist.csv
  - https://projects.fivethirtyeight.com/trump-approval-data/approval_topline.csv
---
# Congress Generic Ballot Polls

This contains the raw data behind "[Are Democrats Winning The Race For Congress?](https://projects.fivethirtyeight.com/congress-generic-ballot-polls/)"
