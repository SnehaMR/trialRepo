# Riddler - Solutions to "Pick A Number, Any Number"

This directory contains the raw data behind the puzzle [Pick A Number, Any Number](https://fivethirtyeight.com/features/pick-a-number-any-number/). A discussion of the solution is in the [following week's puzzle](https://fivethirtyeight.com/features/is-this-bathroom-occupied/).
