# An Inconvenient Sequel

Raw data behind the story [Al Gore’s New Movie Exposes The Big Flaw In Online Movie Ratings](https://fivethirtyeight.com/features/al-gores-new-movie-exposes-the-big-flaw-in-online-movie-ratings/)

Data contains [IMDb ratings](http://www.imdb.com/title/tt6322922/ratings) for the film "An Inconvenient Sequel: Truth to Power" collected daily from July 17 to August 29, 2017.
