# American Health Care Act Polls

The raw data behind the story [Why The GOP Is So Hell-Bent On Passing An Unpopular Health Care Bill](https://fivethirtyeight.com/features/why-the-gop-is-so-hell-bent-on-passing-an-unpopular-health-care-bill)
