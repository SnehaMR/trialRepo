`SOUTH.csv` and `MIDWEST.csv` contain individual responses from surveys about regional identification conducted for FiveThirtyEight by SurveyMonkey.

See also: 

 * http://fivethirtyeight.com/datalab/which-states-are-in-the-south/
 * http://fivethirtyeight.com/datalab/what-states-are-in-the-midwest/
 * http://fivethirtyeight.com/datalab/weve-published-our-data-on-the-south-and-midwest/
