### Flying Etiquette Survey

Results of a SurveyMonkey survey commissioned by FiveThirtyEight for the story [41 Percent of Fliers Say It’s Rude To Recline Your Airplane Seat](http://fivethirtyeight.com/datalab/airplane-etiquette-recline-seat)
